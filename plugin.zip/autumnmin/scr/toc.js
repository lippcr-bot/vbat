function execute(input) {
    var doc = Html.parse(input.responseBody);
    
    var title = doc.select("h1").first().text();
    var author = doc.select(".author, .post-meta").text();
    var cover = doc.select("img.attachment-post-thumbnail").first().attr("src") || "";
    var intro = doc.select(".entry-content p").first().text() || "";
    
    var $chapters = doc.select("article.post .entry-title a, .chapter-list a");
    
    var novel = {
        title: title || "Unknown",
        author: author || "",
        cover: cover,
        summary: intro,
        status: NovelStatus.UNKNOWN
    };
    
    var chapters = [];
    for (var i = 0; i < $chapters.size(); i++) {
        var e = $chapters.get(i);
        chapters.add(new Chapter(e.text(), e.attr("href")));
    }
    
    return Response.success(novel, chapters);
}
