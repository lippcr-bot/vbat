function execute(input) {
    var doc = Html.parse(input.responseBody);
    
    var title = doc.select('title').text().replace(' - Autumn MIN', '');
    var chapters = [];
    
    // Tìm tất cả link chương
    var $links = doc.select('a[href*="/chuong-"], .chapter-item a, article a');
    for (var i = 0; i < $links.size(); i++) {
        var e = $links.get(i);
        var href = e.attr('href');
        if (href && href.includes(input.url.host)) {
            chapters.add(new Chapter(e.text(), href));
        }
    }
    
    var novel = {
        title: title,
        author: "Autumn MIN",
        cover: "",
        summary: "",
        status: NovelStatus.UNKNOWN
    };
    
    return Response.success(novel, chapters);
}
