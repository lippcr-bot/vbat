function execute(input) {
    var doc = Html.parse(input.responseBody);
    
    // Xóa header, sidebar, ads
    doc.select("header, footer, nav, aside, .comments").remove();
    
    var title = doc.select("h1.entry-title, h2").first().text() || "";
    var content = doc.select(".entry-content, .post-content").html();
    
    return Response.success(content, title);
}
