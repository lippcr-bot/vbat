function execute(input) {
    return Response.error("Trang chủ chưa được hỗ trợ");
}
